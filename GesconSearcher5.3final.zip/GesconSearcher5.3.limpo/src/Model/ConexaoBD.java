/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.sql.*;
import javax.swing.JOptionPane;
import java.sql.Statement;  
import java.sql.Connection;  
import java.sql.DriverManager;
/**
 *
 * @author 180401761
 */
public class ConexaoBD {
    
    Connection conn;
    
    public void conectar(){
      
        try{
        Class.forName("org.postgresql.Driver");
        System.out.println("Driver Ok");
        } catch (ClassNotFoundException c){
          JOptionPane.showMessageDialog(null,"ERRO DRIVER");  
        }
        
        String serverName="localhost";
        String database="Gescon";
        String url="jdbc:postgresql://"+serverName+"/"+database;
        String user="postgres";
        String password ="leadguitar";
        
        try{
        conn = DriverManager.getConnection(url,user,password);
        System.out.println("Conexão Ok");
        } catch (SQLException e){
           JOptionPane.showMessageDialog(null,"ERRO NA CONEXÃO COM BD"); 
        }
        
        }
    
    
}
