/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author 180401761
 */
public class Produtos {
    int cod_produtos;
    int cod_cliente;
    String nome;
    double valor;
    int estoque;
    String categoria;
    String descricao;
    
    
    public String toStringCod_produtos(){  
        return String.valueOf(cod_produtos) ;  
    } 
    
    public String toStringCod_clientes(){  
        return String.valueOf(cod_cliente) ;  
    }
    
    public String toStringValor(){  
        return String.valueOf(valor);  
    }
    
    public String toStringEstoque(){  
        return String.valueOf(estoque) ;  
    }
    
    public String toStringNome(){  
        return nome ;  
    }  
    public String toStringCategoria(){  
        return categoria;  
    } 
    
    public String toStringDescricao(){  
        return descricao;  
    }
    
    
    
}
