/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author 330263
 */
public class Cadastro {
    
    int cod_cadastro;
    int cod_cliente;
    String nomefuncionario;
    String login;
    String senha;
    
    public String toStringCod_cadastro(){  
        return String.valueOf(cod_cadastro) ;  
    } 
    
    public String toStringCod_cliente(){  
        return String.valueOf(cod_cliente) ;  
    } 
    
    public String toStringNomefuncionario(){  
        return nomefuncionario ;  
    }
    
    public String toStringLogin(){  
        return login ;  
    } 

     public String toStringSenha(){  
        return senha ;  
    } 
    
    
}
