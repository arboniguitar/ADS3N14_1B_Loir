/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author 180401761
 */
public class Servicos {
    int cod_servicos;
    int cod_cliente;
    String servico;
    String categoria;
    String descricao;
    
    public String toStringCod_servicos(){  
        return String.valueOf(cod_servicos) ;  
    } 
    
    public String toStringCod_cliente(){  
        return String.valueOf(cod_cliente) ;  
    }
            
    public String toStringServico(){  
        return servico ;  
    }  
    public String toStringCategoria(){  
        return categoria;  
    } 
    
    public String toStringDescricao(){  
        return descricao;  
    }
    
}
