package Model;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.table.DefaultTableModel;

public class ConexaoLogin {
    
    private Connection conexao;
    
    public ConexaoLogin() {
		
        try {
            Class.forName("org.postgresql.Driver");
            String url = "jdbc:postgresql://localhost:5432/Gescon"; //Trocar "gescon" para sua database
            String usuario = "postgres"; //Login
            String senha = "leadguitar"; //Senha
            conexao = DriverManager.getConnection(url, usuario, senha);
	} catch ( Exception e ) {
	    System.out.println(e.getLocalizedMessage());
	    throw new IllegalArgumentException(e);
	}
    }    
    
    public Connection getConnection(){
	return this.conexao;
    }
    
    public ResultSet executeQuery(String comandoSql) {
	ResultSet result = null;	
        try {
            
            Statement s = conexao.createStatement();
            result = s.executeQuery(comandoSql);
            
        } catch (SQLException ex) {
            Logger.getLogger(ConexaoLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
        return result;
    }
    
    public Statement createStatement() throws SQLException {
        return conexao.createStatement();
    }
	
    public int executeUpdate(String comandoSql) {
		
	int result = 0;
	
        Statement s;
        try {
            s = conexao.createStatement();
            result = s.executeUpdate(comandoSql);
        } catch (SQLException ex) {
            Logger.getLogger(ConexaoLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
	return result;
    }
    
    public void limpaTable(DefaultTableModel modelo){
       while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }       
    }
    
    public void disconnect(){
        try {
            conexao.close();
        } catch (SQLException ex) {
            Logger.getLogger(ConexaoLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}