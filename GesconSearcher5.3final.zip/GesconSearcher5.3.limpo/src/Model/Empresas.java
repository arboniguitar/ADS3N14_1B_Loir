/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Model;

/**
 *
 * @author 180401761
 */
public class Empresas {
    int cod_cliente;
    String razaosocial;
    String nomefantasia;
    int cnpj;
    int inscrestadual;
    int inscrmunicipal;
    int cep;
    String endereco;
    int numero;
    String complemento;
    String bairro;
    String cidade;
    String estado;
    String email;
    String site;
    int telefone1;
    int telefone2;
    int telefone3;
    
    
    public String toStringCod_cliente(){  
        return String.valueOf(cod_cliente) ;  
    } 
    
    public String toStringRazaosocial(){  
        return razaosocial ;  
    }
    
    public String toStringNomefantasia(){  
        return nomefantasia ;  
    } 

     public String toStringCnpj(){  
        return String.valueOf(cnpj) ;  
    } 
    
     public String toStringInscrestadual(){  
        return String.valueOf(inscrestadual) ;  
    } 
     
      public String toStringInscrmunicipal(){  
        return String.valueOf(inscrmunicipal) ;  
    } 
    
     public String toStringCep(){  
        return String.valueOf(cep) ;  
    } 
     
     public String toStringEndereco(){  
        return endereco ;  
    }
     
       public String toStringNumero(){  
        return String.valueOf(numero) ;  
    } 
       
       
      public String toStringComplemento(){  
        return complemento ;  
    }
      
       public String toStringBairro(){  
        return bairro ;  
    }
       
        public String toStringCidade(){  
        return cidade ;  
    }
        
        public String toStringEstado(){  
        return estado ;  
    }
        
        public String toStringEmail(){  
        return email ;  
    }
        
         public String toStringSite(){  
        return site ;  
    }
      
      public String toStringTelefone1(){  
        return String.valueOf(telefone1) ;  
    } 
      
      public String toStringTelefone2(){  
        return String.valueOf(telefone2) ;  
    } 
       
        public String toStringTelefone3(){  
        return String.valueOf(telefone3) ;  
    } 
     
     
     
     
     
     
     
    
      
    
    
    
   
    
}
