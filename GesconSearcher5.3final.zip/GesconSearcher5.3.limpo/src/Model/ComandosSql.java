/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.sql.*;
import java.util.ArrayList;

/**
 *
 * @author 180401761
 */
public class ComandosSql {
    
    Statement stm;
    ResultSet rs;
    ConexaoBD c = new ConexaoBD();
    
    
    public ArrayList<Produtos> ExecQueryProdutos (String sql) throws Exception{
        
        ArrayList<Produtos> list = new ArrayList<Produtos>();
        
        try{
        c.conectar(); 
        stm = c.conn.createStatement();
        
        rs = stm.executeQuery(sql);
       
        while (rs.next()){
            Produtos p = new Produtos();
            //System.out.println(rs.getInt("cod_produtos"));
            p.cod_produtos = rs.getInt("cod_produtos");
            p.cod_cliente = rs.getInt("cod_cliente");       
            p.nome = rs.getString("nome");
            p.valor = rs.getDouble("valor");
            p.estoque = rs.getInt("estoque"); 
            p.categoria = rs.getString("categoria");
            p.descricao = rs.getString("descricao");
            list.add(p);
            
        }
        
        }catch (SQLException e){
                                 
            throw new Exception(" sem Sucesso");
        }
        return list;
    }
    
    
    public ArrayList<Servicos> ExecQueryServicos (String sql) throws Exception{
        
        ArrayList<Servicos> list = new ArrayList<Servicos>();
        
        try{
        c.conectar(); 
        stm = c.conn.createStatement();
        
        rs = stm.executeQuery(sql);
       
        while (rs.next()){
            Servicos s = new Servicos();
            //System.out.println(rs.getInt("cod_servicos"));
            s.cod_servicos = rs.getInt("cod_servicos");
            s.cod_cliente = rs.getInt("cod_cliente");       
            s.servico = rs.getString("servico");
            s.categoria = rs.getString("categoria");
            s.descricao = rs.getString("descricao");
            list.add(s);
            
        }
        
        }catch (SQLException e){
                                 
            throw new Exception(" sem Sucesso");
        }
        return list;
    }
    
    
    public ArrayList<Cadastro> ExecQueryCadastro (String sql) throws Exception{
        
        ArrayList<Cadastro> list = new ArrayList<Cadastro>();
        
        try{
        c.conectar(); 
        stm = c.conn.createStatement();
        
        rs = stm.executeQuery(sql);
       
        while (rs.next()){
            Cadastro cad = new Cadastro();
            //System.out.println(rs.getInt("cod_servicos"));
            cad.cod_cadastro = rs.getInt("cod_cadastro");
            cad.cod_cliente = rs.getInt("cod_cliente");       
            cad.nomefuncionario = rs.getString("nomefuncionario");
            cad.login = rs.getString("login");
            cad.senha = rs.getString("senha");
            list.add(cad);
            
        }
        
        }catch (SQLException e){
                                 
            throw new Exception(" sem Sucesso");
        }
        return list;
    }
    
    
   
    public ArrayList<Empresas> ExecQueryEmpresas (String sql) throws Exception{
        
        ArrayList<Empresas> list = new ArrayList<Empresas>();
        
        try{
        c.conectar(); 
        stm = c.conn.createStatement();
        
        rs = stm.executeQuery(sql);
       
        while (rs.next()){
            Empresas cli = new Empresas();
            //System.out.println(rs.getInt("cod_cliente"));
            cli.cod_cliente = rs.getInt("cod_cliente");
            cli.razaosocial = rs.getString("razaosocial");
            cli.nomefantasia = rs.getString("nomefantasia");
            cli.cnpj = rs.getInt("cnpj");
            cli.inscrmunicipal = rs.getInt("inscrmunicipal");
            cli.inscrestadual = rs.getInt("inscrestadual");
            cli.cep = rs.getInt("cep");
            cli.endereco = rs.getString("endereco");
            cli.numero = rs.getInt("numero");
            cli.complemento = rs.getString("complemento");
            cli.bairro = rs.getString("bairro");
            cli.cidade = rs.getString("cidade");
            cli.estado = rs.getString("estado");
            cli.email = rs.getString("email");
            cli.site = rs.getString("site");
            cli.telefone1 = rs.getInt("telefone1");
            cli.telefone2 = rs.getInt("telefone2");
            cli.telefone3 = rs.getInt("telefone3");
            list.add(cli);
            
        }
        
        }catch (SQLException e){
                                 
            throw new Exception(" sem Sucesso");
        }
        return list;
    }
    
     public void ExecSQL(String sql) throws Exception{
            
             
        try{
        c.conectar(); 
        stm = c.conn.createStatement();
        
        int result = stm.executeUpdate(sql);
        if (result > 0){
            throw new Exception(" com Sucesso");             
        }
        
        
        }catch (SQLException e){
                                 
            throw new Exception(" sem Sucesso");
        }
    
        
        
    }
    
    
    
}
