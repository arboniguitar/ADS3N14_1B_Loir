﻿
CREATE TABLE TB_Cliente
(
COD_Cliente SERIAL PRIMARY KEY
, razaoSocial VARCHAR(30) NOT NULL
, nomeFantasia VARCHAR(30) NOT NULL
, cnpj INTEGER
, inscrMunicipal INTEGER
, inscrEstadual INTEGER
, cep INTEGER 
, endereco VARCHAR(30)
, numero INTEGER
, complemento VARCHAR(10)
, bairro VARCHAR(30)
, cidade VARCHAR(30)
, estado CHAR(2)
, email VARCHAR(30)
, site VARCHAR(30)
, telefone1 FLOAT
, telefone2 FLOAT
, telefone3 FLOAT
--logo
);

CREATE TABLE TB_Produtos
(
COD_Produtos SERIAL PRIMARY KEY
, COD_Cliente INTEGER REFERENCES TB_Cliente(COD_Cliente)
, nome VARCHAR(30) NOT NULL
, valor NUMERIC(10,2)
, estoque INTEGER
, categoria VARCHAR(30)
, descricao VARCHAR(200)
--foto
);

CREATE TABLE TB_Servicos
(
COD_Servicos SERIAL PRIMARY KEY
, COD_Cliente INTEGER REFERENCES TB_Cliente(COD_Cliente)
, servico VARCHAR(30) NOT NULL
, categoria VARCHAR(30)
, descricao VARCHAR(200)
);

CREATE TABLE TB_Cadastro
(
COD_Cadastro SERIAL PRIMARY KEY
, COD_Cliente INTEGER REFERENCES TB_Cliente(COD_Cliente)
, nomeFuncionario VARCHAR(30) NOT NULL
, login VARCHAR(30) NOT NULL
, senha VARCHAR(10) NOT NULL
);
