package Principal;

import java.io.InputStreamReader;
import java.util.Scanner;

import com.sun.corba.se.spi.orbutil.fsm.Input;

import Grafo.LeAresta;

public class AppGrafo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LeAresta ar = new LeAresta();
		
		ar.ler();
		
		
		Scanner ler = new Scanner(System.in);
		
		System.out.println("Informe o V�rtice de Origem: \n");
		String  v1 = ler.next();
		System.out.println("Informe o V�rtice de Destino: \n");
		String v2 = ler.next();
		
		
		ar.setOrigem(v1);
		ar.setDestino(v2);
		
		
		ar.ProcuraAresta();
	}

}
