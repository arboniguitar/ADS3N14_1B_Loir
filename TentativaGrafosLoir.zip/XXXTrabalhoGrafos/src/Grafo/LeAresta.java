package Grafo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.StringTokenizer;

public class LeAresta {
	
	//Declara��o das Vari�veis
	 /**
	 * 
	 */
	private String origem;         	// Armazena o Vertice de origem  
     private String destino;      	// Armazena o vertice de destino  
     private String custo;       	// Armazena o valor do custo de deslocamento entre os dois v�rtices
     private int v1 = -1;			//Valor v1 vai receber o valor inteiro da origem
     private int v2 = -1;			//valor v2 vai receber o valor inteiro do destino
     private double custoD;
     
        
     
     
	

	public double getCustoD() {
		return custoD;
	}

	public void setCustoD(double custoD) {
		this.custoD = custoD;
	}

	public int getV1() {
		return v1;
	}

	public void setV1(int v1) {
		this.v1 = v1;
	}

	public int getV2() {
		return v2;
	}

	public void setV2(int v2) {
		this.v2 = v2;
	}

	public String getOrigem() {
		return origem;
	}

	public void setOrigem(String origem) {
		this.origem = origem;
	}

	public String getDestino() {
		return destino;
	}

	public void setDestino(String destino) {
		this.destino = destino;
	}

	public String getCusto() {
		return custo;
	}

	public void setCusto(String custo) {
		this.custo = custo;
	}

	public void ler() {
	   
	    File arq = new File("Arestas.txt");
	 
	    try {
	        //Indicamos o arquivo que ser� lido
	        FileReader fileReader = new FileReader(arq);
	 
	        //Criamos o objeto bufferReader que nos
	        // oferece o m�todo de leitura readLine()
	        BufferedReader bufferedReader =
	            new BufferedReader(fileReader);
	 
	        //String que ir� receber cada linha do arquivo
	        String linha = "";
	 
	        //Fazemos um loop linha a linha no arquivo,
	        // enquanto ele seja diferente de null.
	        //O m�todo readLine() devolve a linha na
	        // posicao do loop para a variavel linha.
	        while ( ( linha = bufferedReader.readLine() ) != null) {
	            //Aqui imprimimos a linha
	            System.out.println(linha);
	        }
	 
	        //liberamos o fluxo dos objetos
	        // ou fechamos o arquivo
	        fileReader.close();
	        bufferedReader.close();
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public void ProcuraAresta() {  
	      String linha = null;  
	  
	      try {  
	         FileReader reader = new FileReader("Arestas.txt"); // Localiza��o do Arquivo  
	         BufferedReader leitor = new BufferedReader(reader);  
	         StringTokenizer st = null;  
	         
	       
	  
	         while ((linha = leitor.readLine()) != null) {  
	                                            
	              
	        	
			     
			       
	            // UTILIZA DELIMITADOR ; PARA DIVIDIR OS CAMPOS  
	            st = new StringTokenizer(linha, ";");  
	            String dados = null;  
	  
	            while (st.hasMoreTokens()) {  
	  
	               // Campo Origem  
	               origem = st.nextToken();  
	               origem = dados;  
	               //v1 = Integer.parseInt(origem);
	                 
	               // Campo Destino  
	               destino= st.nextToken();  
	               destino = dados; 
	               //v2 = Integer.parseInt(destino);
	                 
	              
	               // Campo Custo  
	               custo = st.nextToken();  
	               custo = dados;  
	               custoD = Double.parseDouble(getCusto());
	               
	                 
	               System.out.println("Vertice de Partida " + origem);  
	               System.out.println("Vertice de Chegada " + destino);  
	               System.out.println("Custo " + custoD);  
	            }  
	         }  
	         leitor.close();  
	         reader.close();  
	  
	      } catch (Exception e) {  
	         e.printStackTrace();  
	      }  
	   }  
	  
	  
	
	
	
	
	

}
